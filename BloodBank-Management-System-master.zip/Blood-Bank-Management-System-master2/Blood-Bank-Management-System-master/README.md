## Blood-Bank-Management-System

### How to run a App

### Create a virtual environment

Download python & pip

### download requirement file

`$ pip install -r requirement.txt`

then

`$ python manage.py migrate`

`$ python manage.py createsuperuser`

### start the app

`$ python manage.py runserver`

Open browser, <http://localhost:8000>

### stop the app

           Ctrl+C
